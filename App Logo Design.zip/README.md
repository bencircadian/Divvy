
  # App Logo Design

  This is a code bundle for App Logo Design. The original project is available at https://www.figma.com/design/HuNtwQk2Ou769UmW3RpF3M/App-Logo-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  